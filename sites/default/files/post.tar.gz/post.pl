#!/usr/bin/perl
use CGI::Carp qw( fatalsToBrowser );

# PERL MODULES WE WILL BE USING

use Data::Dumper;
use CGI qw/:standard/;

use DBI;
use DBD::mysql;

# HTTP HEADER
print "Content-type: text/html \n\n";
print header;

my $lastvalue = param('L')    or die "Value1 not in parameter list";
my $currentvalue = param('C')    or die "Value2 not in parameter list";

# CONFIG VARIABLES
$platform = "mysql";
$database = "database_name";
$host = "localhost";
$port = "3306";
$tablename = "DATA";
$user = "database_username";
$pw = "database_password";

# DATA SOURCE NAME
$dsn = "dbi:$platform:$database:$host:$port";

# PERL DBI CONNECT
$connect = DBI->connect($dsn, $user, $pw) or die "Unable to connect: $DBI::errstr\n";

$vtime = (time()*1000)-1000;

# PREPARE THE QUERY
$query = "INSERT INTO DATA (A, B) VALUES ($lastvalue,$vtime)";
$query_handle = $connect->prepare($query);

# EXECUTE THE QUERY
$query_handle->execute();

$vtime = time()*1000;

# PREPARE THE QUERY
$query = "INSERT INTO DATA (A, B) VALUES ($currentvalue,$vtime)";
$query_handle = $connect->prepare($query);

# EXECUTE THE QUERY
$query_handle->execute();
