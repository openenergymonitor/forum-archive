//AWT Graphics library
import java.awt.*; 
import javax.swing.*;
import java.math.*;
import java.awt.geom.*; 

//The Frame class
class Frame extends JFrame
{
   GCanvas canvas;

   public Frame()
   {

      super("A03"); 

      setBounds(0,0,200,150);

      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      Container con = this.getContentPane();

      canvas = new GCanvas(); 

      con.add(canvas);

      setVisible(true);

      canvas.repaint();
   }

}


class GCanvas extends Canvas
{
 
   //We need to first declare the values we want to print to the frame.
   //In this example the arduino is sending 2 values.
   //The file ArduinoComm reads them in and then sets the values here by
   //calling for valueA: program.myFrame.canvas.valueA=valuE

   double valueA = 0.0;
   double valueB = 0.0;

   Dimension offDimension;
   Image offImage;
   Graphics offGraphics;

   public void update(Graphics g) 
   {
      Dimension d = size();

      // Create the offscreen graphics context
      if ((offGraphics == null)
         || (d.width != offDimension.width)
	 || (d.height != offDimension.height)) 
         {
	    offDimension = d;
	    offImage = createImage(d.width, d.height);
	    offGraphics = offImage.getGraphics();
	 }

      // Erase the previous image
      offGraphics.setColor(getBackground());
      offGraphics.fillRect(0, 0, d.width, d.height);
      offGraphics.setColor(Color.black);

      offGraphics.setColor(new Color(0.0f,0.0f,0.0f));

      //This is where we print the values to the frame.
      // 1) Convert double to a string
      String str = "Value A is: "+Double.toString(valueA);
      // 2) Draw the string to the frame.
      offGraphics.drawString(str,50,50);

      str = "Value B is: "+Double.toString(valueB);
      offGraphics.drawString(str,50,70);

      // Paint the image onto the screen
      g.drawImage(offImage, 0, 0, null);
   }

   public void paint(Graphics g) 
   {
      if (offImage != null) 
      {
         g.drawImage(offImage, 0, 0, null);
      }
   }
}
