/*
  EnergyMonitor2CT.cpp   
  Updated: 8 December 2010
  Contributors: Trystan Lea and Bear Kaufmann
  GNU GPL openenergymonitor.org and a AllPowerLabs: gekgasifier.com
*/

#ifndef EnergyMonitor2CT_h
#define EnergyMonitor2CT_h

#include "WProgram.h"

class EnergyMonitor
{
  public:

    void setPins(int _inPinV,int _inPinI1,int _inPinI2);
    void calibration(double _VCAL, double _ICAL1, double _ICAL2, double _PHASECAL);
    void calc(int wavelengths, int minF, int maxF);
    
    //Useful value variables
    double realPower1,
       apparentPower1,
       powerFactor1,
       Vrms,
       Irms1;
    //Useful value variables
    double realPower2,
       apparentPower2,
       powerFactor2,
       Irms2;

    double frequency;
  private:

    //Set Voltage and current input pins
    int inPinV;
    int inPinI1;
    int inPinI2;
    //Calibration coeficients
    //These need to be set in order to obtain accurate results
    double VCAL;
    double ICAL1;
    double ICAL2;
    double PHASECAL;
    //--------------------------------------------------------------------------------------
    // Variable declaration for emon_calc procedure
    //--------------------------------------------------------------------------------------
	int lastSampleV,sampleV;   //sample_ holds the raw analog read value, lastSample_ holds the last sample
	int lastSampleI1,sampleI1;
	int lastSampleI2,sampleI2;	                      

	double lastFilteredV,filteredV;                   //Filtered_ is the raw analog value minus the DC offset
	double lastFilteredI1, filteredI1;
	double lastFilteredI2, filteredI2;               

	double phaseShiftedV;                             //Holds the calibrated phase shifted voltage.

	double sqV,sumV;
	double sqI1,instP1,sumI1,sumP1;
	double sqI2,instP2,sumI2,sumP2;

	int startV;                                       //Instantaneous voltage at start of sample window.

	boolean lastVCross, checkVCross;                  //Used to measure number of times threshold is crossed.
	int crossCount;                                   // ''
        
};

#endif
