/*
  EnergyMonitor2CT.cpp   
  Updated: 8 December 2010
  Contributors: Trystan Lea and Bear Kaufmann
  GNU GPL openenergymonitor.org and a AllPowerLabs: gekgasifier.com
*/

#include "WProgram.h"
#include "EnergyMonitor2CT.h"

//--------------------------------------------------------------------------------------
// Sets the pins to be used for voltage and current sensors
//--------------------------------------------------------------------------------------
void EnergyMonitor::setPins(int _inPinV,int _inPinI1,int _inPinI2)
{
   inPinV = _inPinV;
   inPinI1 = _inPinI1;
   inPinI2 = _inPinI2;
}

//--------------------------------------------------------------------------------------
// Sets the calibration values
//--------------------------------------------------------------------------------------
void EnergyMonitor::calibration(double _VCAL, double _ICAL1, double _ICAL2, double _PHASECAL)
{
   VCAL = _VCAL;
   ICAL1 = _ICAL1;
   ICAL2 = _ICAL2;
   PHASECAL = _PHASECAL;
}

//--------------------------------------------------------------------------------------
// emon_calc procedure
// Calculates realPower,apparentPower,powerFactor,Vrms,Irms,kwh increment
// From a sample window of the mains AC voltage and current.
// The Sample window length is defined by the number of wavelengths we choose to measure.
//--------------------------------------------------------------------------------------
void EnergyMonitor::calc(int wavelengths, int minF, int maxF)
{
  unsigned long timeout = (1000000.0 / minF)*wavelengths; // frequency to microseconds

 
  int crossCount = 0;                             //Used to measure number of times threshold is crossed.
  int numberOfSamples = 0;                        //This is now incremented  

  //Save initial voltage 
  startV = ADC_ReadChanSync(inPinV);
  //startV = analogRead(inPinV);

  //-------------------------------------------------------------------------------------------------------------------------
  // 2) Main measurment loop
  //------------------------------------------------------------------------------------------------------------------------- 
  unsigned long start = micros();    //millis()-start makes sure it doesnt get stuck in the loop if there is an error.
  
  while ((crossCount < (wavelengths*2)) && ((micros()-start)<timeout) ) 
  {
    numberOfSamples++;                            //Count number of times looped.

    lastSampleV=sampleV;                          //Used for digital high pass filter
    lastSampleI1=sampleI1;
    lastSampleI2=sampleI2;
    
    lastFilteredV = filteredV;                    //Used for offset removal
    lastFilteredI1 = filteredI1;                
    lastFilteredI2 = filteredI2;                    
    //-----------------------------------------------------------------------------
    // A) Read in raw voltage and current samples
    //-----------------------------------------------------------------------------
    sampleV = ADC_ReadChanSync(inPinV);    // ADC_ReadChanSync used by allPowerLabs GEK   
    sampleI1 = ADC_ReadChanSync(inPinI1);
    sampleI2 = ADC_ReadChanSync(inPinI2);

    //sampleV = analogRead(inPinV);
    //sampleI1 = analogRead(inPinI1);
    //sampleI2 = analogRead(inPinI2);
    //-----------------------------------------------------------------------------
    // B) Apply digital high pass filters to remove 2.5V DC offset (centered on 0V).
    //-----------------------------------------------------------------------------
    filteredV = 0.996*(lastFilteredV+sampleV-lastSampleV);
    filteredI1 = 0.996*(lastFilteredI1+sampleI1-lastSampleI1);
    filteredI2 = 0.996*(lastFilteredI2+sampleI2-lastSampleI2);
   
    //-----------------------------------------------------------------------------
    // C) Root-mean-square method voltage
    //-----------------------------------------------------------------------------  
    sqV= filteredV * filteredV;                 //1) square voltage values
    sumV += sqV;                                //2) sum
    
    //-----------------------------------------------------------------------------
    // D) Root-mean-square method current
    //-----------------------------------------------------------------------------   
    sqI1 = filteredI1 * filteredI1;                //1) square current values
    sumI1 += sqI1;                                 //2) sum 

    sqI2 = filteredI2 * filteredI2;                //1) square current values
    sumI2 += sqI2;                                 //2) sum 
    
    //-----------------------------------------------------------------------------
    // E) Phase calibration
    //-----------------------------------------------------------------------------
    phaseShiftedV = lastFilteredV + PHASECAL * (filteredV - lastFilteredV); 
    
    //-----------------------------------------------------------------------------
    // F) Instantaneous power calc
    //-----------------------------------------------------------------------------   
    instP1 = phaseShiftedV * filteredI1;          //Instantaneous Power
    sumP1 +=instP1;                               //Sum  
    
    instP2 = phaseShiftedV * filteredI2;          //Instantaneous Power
    sumP2 +=instP2;                               //Sum  
    
    //-----------------------------------------------------------------------------
    // G) Find the number of times the voltage has crossed the initial voltage
    //    - every 2 crosses we will have sampled 1 wavelength 
    //    - so this method allows us to sample an integer number of wavelengths which increases accuracy
    //-----------------------------------------------------------------------------       
    lastVCross = checkVCross;                     
    if (sampleV > startV) checkVCross = true; 
                     else checkVCross = false;
    if (numberOfSamples==1) lastVCross = checkVCross;                  
                     
    if (lastVCross != checkVCross) crossCount++;
  }
  unsigned long tlength = micros()-start;

  //-------------------------------------------------------------------------------------------------------------------------
  // 3) Post loop calculations
  //------------------------------------------------------------------------------------------------------------------------- 

  double ftmp = (1000000.0/(tlength/wavelengths));

  if (ftmp>minF && ftmp<maxF){

  frequency = ftmp;

  //Calculation of the root of the mean of the voltage and current squared (rms)
  //Calibration coeficients applied. 
  Vrms = VCAL*sqrt(sumV / numberOfSamples); 
  Irms1 = ICAL1*sqrt(sumI1 / numberOfSamples); 
  Irms2 = ICAL2*sqrt(sumI2 / numberOfSamples); 

  //Calculation power values
  realPower1 = VCAL*ICAL1*sumP1 / numberOfSamples;
  realPower2 = VCAL*ICAL2*sumP2 / numberOfSamples;

  apparentPower1 = Vrms * Irms1;
  apparentPower2 = Vrms * Irms2;

  powerFactor1 = realPower1 / apparentPower1;
  powerFactor2 = realPower2 / apparentPower2;

  }
  //Reset accumulators
  sumV = 0;
  sumI1 = 0;
  sumP1 = 0;
  sumI2 = 0;
  sumP2 = 0;
//--------------------------------------------------------------------------------------       
 

}

