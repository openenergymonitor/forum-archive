/*
  CurrentSensorDC.h - Library for openenergymonitor
  Created by Trystan Lea, May 16 2010
  Licenced under GPL
*/

#ifndef CurrentSensorDC_h
#define CurrentSensorDC_h

#include "WProgram.h"

class CurrentSensorDC
{
  public:
    CurrentSensorDC(int _analogInPin, double _cal_m, double _cal_c);

    double getCurrentSmooth(int AVnum, int SMnum);
    double getCurrent();
    int getADC();
  private:

    int analogInPin;
    double cal_m;
    double cal_c;

    double smoothVal[10];

};

#endif
