/*
  CurrentSensorDC.cpp - Library for openenergymonitor
  Created by Trystan Lea, April 27 2010
  Licenced under GPL
*/

#include "WProgram.h"
#include "CurrentSensorDC.h"

CurrentSensorDC::CurrentSensorDC(int _analogInPin, double _cal_m, double _cal_c )
{

analogInPin = _analogInPin;
cal_m = _cal_m;
cal_c = _cal_c;

}

double CurrentSensorDC::getCurrentSmooth(int AVnum, int SMnum)
{
   double current;
   double isum=0;
   double val;
   double sumPoints=0;

   for (int i=0; i<AVnum; i++)
   {
      val = analogRead(analogInPin);
   
      current = cal_m * val + cal_c; 
      isum=isum+current;
   
   }
   
   current = isum / AVnum;  

   //Multi-point smoothing
   //Shifts points along 1, so that we average the last x number of points.
   for (int i=SMnum; i>1; i--) smoothVal[i]=smoothVal[i-1];
   smoothVal[1] = current;
   //Sum all points
   for (int i=1; i<SMnum+1; i++) sumPoints = sumPoints+smoothVal[i]; 
   //Find the average. 
   current = sumPoints/SMnum;

   if (current<0.0) current = 0.0;
   return current;
}


double CurrentSensorDC::getCurrent()
{
   double current;
   double val;

      val = analogRead(analogInPin);
   
      current = cal_m * val + cal_c; 

      
   if (current<0.0) current = 0.0; 
   return current;
}


int CurrentSensorDC::getADC()
{
   int ADCval;

      ADCval = analogRead(analogInPin);
   
   return ADCval;
}


