<?php
  //--------------------------------------------------------------------------------------
  // Data poster!
  //--------------------------------------------------------------------------------------

  //---------------------------------------------------------------------------------------
  // Connect to the mysql database
  //---------------------------------------------------------------------------------------
  $lines = file('database.config');

  $lines = str_replace(" ", "", $lines);
  
  $ex_line = explode(':',$lines[0]); $host = $ex_line[1];
  $ex_line = explode(':',$lines[1]); $user = $ex_line[1];
  $ex_line = explode(':',$lines[2]); $pass = $ex_line[1];
  $ex_line = explode(':',$lines[3]); $name = $ex_line[1];

  include 'DB.php';
  $con = mysql_connect($host,$user,$pass);
  $dbs = mysql_select_db($name, $con);

  //---------------------------------------------------------------------------------------
  // Fetch the json string
  //---------------------------------------------------------------------------------------
  $json = $_GET["json"];
  $json = str_replace(chr(92), "", $json);
  //Pass in json
  //$json = '{"house1":"502.5","house1":"0.31","power":"121.1","rpm":"333.1","life":"32.1"}';
  $result = mysql_query("INSERT INTO dump (dump) VALUES ('$json')");  //Place string in dump log for troubleshooting

  //---------------------------------------------------------------------------------------------------
  // Custom json_decode function, specially designed to allow storage of repeated variable keys
  // for example when realPower is included twice in the same string
  //---------------------------------------------------------------------------------------------------
  $json = str_replace('"', '', $json);                    //Remove quote characters "
  $json = str_replace('{', '', $json);                    //Remove JSON start characters
  $json = str_replace('}', '', $json);                    //Remove JSON end characters

  $datapairs = explode(",", $json);                       //Seperate JSON string into individual data pairs. 

  //---------------------------------------------------------------------------------------------------
  //For all datapairs
  //---------------------------------------------------------------------------------------------------
  foreach ($datapairs as $datapair)            
  {
    $datapair = explode(":", $datapair);                       //Divide them into their key and value contituent parts
    $key_plus_timeoffset = $datapair[0];                       //Get the key plus time offset
    $value = $datapair[1];                                     //Get the value

    $key_plus_timeoffset = explode("-", $key_plus_timeoffset); //Split key plus time offset
    $key = $key_plus_timeoffset[0];                            //Get key
    $timeoffset = $key_plus_timeoffset[1];                     //Get time offset

    echo ".";
    //---------------------------------------------------------------------------------------------------
    //Check if the variable has already been registered
    //---------------------------------------------------------------------------------------------------
    $result = mysql_query("SELECT * FROM variables WHERE name='$key'");
    $array = mysql_fetch_array($result);
          
    $time = time()-$timeoffset;                                //get current unix timestamp and then add offset               
    $time = date("Y-n-j H:i:s", $time);                        //convert the unix timestamp to datetime format
    
    //---------------------------------------------------------------------------------------------------
    // If the variable has been registered -> update new value
    //---------------------------------------------------------------------------------------------------
    if ($array) 
    {
      echo "ok";

      //ACUMULATION PROCESS
      if ($array['accum']==1)                                 //If variable has accumulate field flagged
      {
        $result = mysql_query("SELECT * FROM $key ORDER BY time DESC LIMIT 1"); //get last value
        $array = mysql_fetch_array($result);
        $value = $value + $array['data'];                     //add new value to last value
      }
      $result = mysql_query("INSERT INTO $key (time,data) VALUES ('$time','$value')");
    }

    //---------------------------------------------------------------------------------------------------
    // If the variable has not been registered -> register value, 
    //                                            create data table for variable
    //                                            update new value
    //---------------------------------------------------------------------------------------------------
    else
    {
      echo "ok";   

      $result = mysql_query("INSERT INTO variables (name) VALUES ('$key')");
      $result = mysql_query("CREATE TABLE $key (time DATETIME , data FLOAT)"); 
      $result = mysql_query("INSERT INTO $key (time,data) VALUES ('$time','$value')");
    }
  }
?>
