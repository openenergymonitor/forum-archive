<!--------------------------------------------------------------------------------------
  // Index php - displays a variable list which automatically updates 

  // Part of the openenergymonitor.org project
  // Licence: GNU GPL
  // Last update: 26th of September
  // Author: Trystan Lea
-------------------------------------------------------------------------------------->
<html>
 <head>
 <title>Input variables</title>
 <link rel="stylesheet" type="text/css" href="theme/style.css" />
    <script language="javascript" type="text/javascript" src="flot/jquery.js"></script>
 </head>
 <body>
 <div id="bound">
   <div id="header"></div>
   <div id="box">
     <div id="topd">
       <div id="title">Input variables</div> 
       <div id="menu"></div>
     </div>

     <div id="maintext">

     <div class="data"> </div>   
     <p style='font-size:11px;' class="inc"></p>
                                
<script id="source" language="javascript" type="text/javascript">
//--------------------------------------------------------------------------------------
$(function () {
  //--------------------------------------------------------------------------------------
  // Variable declaration
  //--------------------------------------------------------------------------------------
  var inc = 0;                                    //refresh counter

  fetchData();
  function fetchData()
  {
    //--------------------------------------------------------------------------------------
    // Fetch Data
    //--------------------------------------------------------------------------------------
    $.ajax({                                      //Using JQuery and AJAX
      url: 'getIndex.php',                        //data.php loads data
     // dataType: 'json',  
      success: function(data) 
      {
        var htmlstr="";                           //create empty string to store html

        if (data=="[]") 
        {
          htmlstr=
          "<div id=variablebox >"
          +"<b>Hello!</b></br> You dont seem to have any data!</br></br>"
          +"To post data send a JSON string from your device, for example try: </br>"
          +"<a href='post.php?json={"
          +'"voltage":"20.1","current":"2.1"}'
          +"'>"
          +'http://yourdomainname/emoncms/post.php?json={"voltage":"20.1","current":"2.1"}</a>'
          +"</div"; 
        }
        else
        {

        var mydata = JSON.parse(data);            //convert JSON string into an array

        for (var z in mydata)                     //for all variables
        {
          var vname = mydata[z][0];               //get name
          var vtime = mydata[z][1];               //get time
          var vval  = mydata[z][2];               //get value

         htmlstr +=                               //add to html string
          "<div id=variablebox >" 
          +"<table border='0'>" 
          +"<tr style='font-size:11px;font-weight: bold; '>"

          +"<th align =left >Variable name:</th>"
          +"<th align =left>Last update time: </th>"
          +"<th align =left>Last value: </th>"
          +"<th align =left>Graph: </th>"
          +"</tr><tr>"
          +"<td width='200'>"+vname+"</td>"
          +"<td width='300'>"+vtime+"</td>"
          +"<td width='150'>"+vval+"</td>"
          +"<td> <a href='graph.php?table="+vname+"'>view</a>"
          +"</tr> </table> </div>";
        }
        }
       $('.data').html(htmlstr);                 //update data placeholder

      } 
    });

    //--------------------------------------------------------------------------------------
    inc++;                                        //Count number of reloads
    $('.inc').html("Refreshed: "+inc);            //Print number of reloads

    setTimeout(fetchData, 2000);                  //Loop
  }
});
//--------------------------------------------------------------------------------------
</script>


   </div>
 </div>
 <div id="footer"></div>
</div>



  

  </body>

</html>  
