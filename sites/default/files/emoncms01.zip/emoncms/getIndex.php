<?php
  //--------------------------------------------------------------------------------------
  // Index Data reader!
  //--------------------------------------------------------------------------------------

  //--------------------------------------------------------------------------------------
  // 1) Load up database
  //--------------------------------------------------------------------------------------

  $lines = file('database.config');

  $lines = str_replace(" ", "", $lines);
  
  $ex_line = explode(':',$lines[0]); $host = $ex_line[1];
  $ex_line = explode(':',$lines[1]); $user = $ex_line[1];
  $ex_line = explode(':',$lines[2]); $pass = $ex_line[1];
  $ex_line = explode(':',$lines[3]); $name = $ex_line[1];

  include 'DB.php';
  $con = mysql_connect($host,$user,$pass);
  $dbs = mysql_select_db($name, $con);

  //--------------------------------------------------------------------------------------
  // Get variable value function
  //--------------------------------------------------------------------------------------
  function getValue($varName)
  {
    $result = mysql_query("SELECT * FROM $varName ORDER BY time DESC LIMIT 1");
    $array = mysql_fetch_array($result);
    $value = $array['data'];

    return $value;
  }

  //--------------------------------------------------------------------------------------
  // Get variable time function
  //--------------------------------------------------------------------------------------
  function getTime($varName)
  {
    $result = mysql_query("SELECT * FROM $varName ORDER BY time DESC LIMIT 1");
    $array = mysql_fetch_array($result);
    $value = $array['time'];

    return $value;
  }

  //--------------------------------------------------------------------------------------
  // Main
  //--------------------------------------------------------------------------------------
  $result = mysql_query("SELECT * FROM variables");          //Select all variables from variables list

  if (!$result)
  {
    $result = mysql_query("CREATE TABLE variables ( name TEXT,accum INT(1))"); 
    $result = mysql_query("CREATE TABLE dump ( text TEXT )"); 
  } 


  $data = array();                                           //create an array to store data
  while($array = mysql_fetch_array($result))                 //for all variables
  {
    $name = $array['name'];                                  //get the variable name

    $time = getTime($name);                                  //time
    $value = getValue($name);                                //value
    $data[] = array($name , $time , $value);                 //create an array
  }
  echo json_encode($data);                                   //encode array as JSON

  mysql_close($con);                                         //close the mysql database
?>
