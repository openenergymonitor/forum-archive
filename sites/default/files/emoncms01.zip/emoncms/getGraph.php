<?php
  //--------------------------------------------------------------------------------------
  // Graph Data reader!
  //--------------------------------------------------------------------------------------


  $last_numrows = $_GET["dlen"];
  $tablename = $_GET["table"];
  //--------------------------------------------------------------------------------------
  // 1) Load up database
  //--------------------------------------------------------------------------------------
  $lines = file('database.config');

  $lines = str_replace(" ", "", $lines);
  
  $ex_line = explode(':',$lines[0]); $host = $ex_line[1];
  $ex_line = explode(':',$lines[1]); $user = $ex_line[1];
  $ex_line = explode(':',$lines[2]); $pass = $ex_line[1];
  $ex_line = explode(':',$lines[3]); $name = $ex_line[1];

  include 'DB.php';
  $con = mysql_connect($host,$user,$pass);
  $dbs = mysql_select_db($name, $con);

  //--------------------------------------------------------------------------------------
  // 2) Check if there is new data to be read
  //--------------------------------------------------------------------------------------
  $result = mysql_query("select * from $tablename");      //Query to find current number of lines
  $new_numrows = mysql_num_rows($result);                //.. current number of lines

  $newlines = $new_numrows-$last_numrows;                //find how many new lines there is

  //--------------------------------------------------------------------------------------
  // 3) If YES: get the new data and send it via a JSON string back to the graphing program
  //--------------------------------------------------------------------------------------
  if ($new_numrows>$last_numrows)                        //If there are new lines then:
  {
    $result = mysql_query("select * from $tablename order by time Desc Limit $newlines"); //get them!

    $data = array();                                     //create an array for them
    while($row = mysql_fetch_array($result))             // for all the new lines
    {
      $dataValue = $row['data'] ;                        //get the datavalue
      $time = strtotime($row['time'])*1000;              //and the time value - converted to unix time * 1000
      $data[] = array($time , $dataValue);               //add time and data to the array
    }
    echo json_encode($data);                             //encode the array as a JSON and send it on to the graphing script
  } else
  {
    echo "0";
  }
  mysql_close($con);                                     //close the mysql database
?>
