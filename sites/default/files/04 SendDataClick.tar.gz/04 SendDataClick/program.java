//Main program class
public class program
{

//Declares the Arduino object field
public static ArduinoComm myArduino;

public static Frame myFrame;

   //Main method
   public static void main(String args[]) 
   {

      myFrame = new Frame();

      myArduino = new ArduinoComm();
      myArduino.start("/dev/ttyUSB0",115200);



   }

}
