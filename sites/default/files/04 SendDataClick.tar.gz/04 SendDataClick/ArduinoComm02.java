//This class:
// - Starts up the communication with the Arduino.
// - Reads the data coming in from the Arduino and
//   converts that data in to a useful form.
// - Closes communication with the Arduino.

//Code builds upon this great example:
//http://www.csc.kth.se/utbildning/kth/kurser/DH2400/interak06/SerialWork.java
//The addition being the conversion from incoming characters to numbers. 

//Load Libraries
import java.io.*;
import java.util.TooManyListenersException;

//Load RXTX Library
import gnu.io.*;

class ArduinoComm implements SerialPortEventListener
{
 
   //Used to in the process of converting the read in characters-
   //-first in to a string and then into a number.
   String rawStr="";
   
   //Declare serial port variable
   SerialPort mySerialPort;

   //Declare input steam
   InputStream in;
   OutputStream out;
 
   boolean stop=false;


   //This open's the communcations port with the arduino
   public void start(String portName,int baudRate)
   {

      stop=false; 
      try 
      {
         //Finds and opens the port
         CommPortIdentifier portId = CommPortIdentifier.getPortIdentifier(portName);
         mySerialPort = (SerialPort)portId.open("my_java_serial" + portName, 2000);
         System.out.println("Serial port found and opened");

         //configure the port
         try 
         {
            mySerialPort.setSerialPortParams(baudRate,
            mySerialPort.DATABITS_8,
            mySerialPort.STOPBITS_1,
            mySerialPort.PARITY_NONE);
            System.out.println("Serial port params set: "+baudRate);
         } 
         catch (UnsupportedCommOperationException e)
         {
            System.out.println("Probably an unsupported Speed");
         }

         //establish stream for reading from the port
         try 
         {
            in = mySerialPort.getInputStream();
            out = mySerialPort.getOutputStream();
         } 
         catch (IOException e) 
         { 
            System.out.println("couldn't get streams");
         }

         // we could read from "in" in a separate thread, but the API gives us events
         try 
         {
            mySerialPort.addEventListener(this);
            mySerialPort.notifyOnDataAvailable(true);
            System.out.println("Event listener added");
         } 
         catch (TooManyListenersException e) 
         {
            System.out.println("couldn't add listener");
         }
      }
      catch (Exception e) 
      { 
         System.out.println("Port in Use: "+e);
      }
   }

   //Used to close the serial port
   public void closeSerialPort() 
   {
      try 
      {
         in.close();
         stop=true; 
         mySerialPort.close();
         System.out.println("Serial port closed");

      }
      catch (Exception e) 
      {
      System.out.println(e);
      }
   }

   //Method sends a character
   public void sendData(char ch)
   {
      try 
      {
         out.write(ch);
      }
      catch (Exception e) 
      {
         System.out.println(e);
      }
   }



/*
   This method reads the characters sent by the arduino
   The Arduino output looks like this:

   128.43A153.25B0.84C242.62D0.63E128.43A153.25B0.84C242.62D0.63E128.43A153.25B0.84C242.62D0.63E

   The method below divides this continuous stream of characters send by the Arduino into values
   The letter after the numbers plus decimal point identifies the numbers and decimal point that
   preceded it.

   So:

   128.43A: value = 128.43 with identifier A (A in this case is real power)
 
   Lets go through this in further detail:

   Program recieves characters one after the other like this:
    ch = 1 - isDigit(ch) = true and so it is added to the string rawStr
    ch = 2 - isDigit(ch) = true and so it is added to the string rawStr
    ch = 8 - isDigit(ch) = true and so it is added to the string rawStr
    ch = . - isDigit(ch) = false but we check if ch='.' and if so it is added to the string rawStr
    ch = 4 - isDigit(ch) = true and so it is added to the string rawStr
    ch = 3 - isDigit(ch) = true and so it is added to the string rawStr
    ch = A - isDigit(ch) = false but - isLetter(ch) = true and so we then convert the rawStr that is now "128.43" to a  double with double value = Double.parseDouble(rawStr);
    Now we have a value with an identifier and we then print the value to terminal but we could just as well 
    if (ch=='A') realPower = value;

    The last thing we do is reset rawStr="" and then the above process is repeated. 

*/
   public void serialEvent(SerialPortEvent event) 
   { 

      //Reads in data while data is available
      while (event.getEventType()== SerialPortEvent.DATA_AVAILABLE && stop==false) 
      {
         try 
         {
            //------------------------------------------------------------------- 
         
            //Read in the available character
            char ch = (char)in.read();

            //If the read character is a letter this means that we have found an identifier.
            if (Character.isLetter(ch)==true && rawStr!="")
            {
               //Convert the string containing the characters accumulated since the last identifier into a double.
               double value = Double.parseDouble(rawStr);

               if (ch=='A')
               {
                  //System.out.println("Value A is: "+value);
                  System.out.print(".");

                  //This is were we send the value identified by A to the frame class
                  //This is done by setting the variable in the frame class to be value:
                  program.myFrame.canvas.valueA=value;
                  
                  //And then we update the frame so that the new value is drawn
                  program.myFrame.canvas.repaint();

               }

               if (ch=='B')
               {
                  //System.out.println("Value B is: "+value);
                  System.out.print(".");

                  program.myFrame.canvas.valueB=value;                  
                  program.myFrame.canvas.repaint();
               }


               //Reset rawStr ready for the next reading
               rawStr = ("");
            } 
            else 
            {
               //Add incoming characters to a string.
               //Only add characters to the string if they are digits. 
               //When the arduino starts up the first characters it sends through are S-t-a-r-t- 
               //and so to avoid adding these characters we only add characters if they are digits.

               if (Character.isDigit(ch))
               {
                  rawStr = ( rawStr + Character.toString(ch));
               } 
               else 
               {
                  //Get the decimal point
                  if (ch=='.')
                  { 
                     rawStr = ( rawStr + Character.toString(ch));
                  }
                  else
                  {
                     System.out.print(ch);
                  }
               } 
            }
         } 
         catch (IOException e) 
         {
         }
      }
   }

}
